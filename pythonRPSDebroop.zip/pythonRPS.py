#Python rock paper scissor game made by Debroop(pythonRPS.py) 
#roll number 235/UCS/049
import random

def rock_paper_scissor():
    #List of choices for the computer to choose from
    choices = ["rock", "paper", "scissor"] 

    #header text
    print("Welcome to Rock, Paper, Scissor!")
    print("Press 'Q' to exit the game.\n")

    while True: #Looping until user decides to quit
        user_choice = input("Enter rock, paper, or scissor: ").lower() #Taking a choice and converting to lowercase
        
        if user_choice == "q": #if Q is pressed user will quit the game
            print("Thank you for playing!")
            break
        
        if user_choice not in choices: #If you choose anything other than the 3 options,it will be invalid
            print("Invalid choice. Please try again.\n")
            continue

        computer_choice = random.choice(choices) #Random choice for computer
        print(f"Computer chose: {computer_choice}")

        if user_choice == computer_choice:  #All different cases using elif statement
            print("It's a tie!\n")
        elif (user_choice == "rock" and computer_choice == "scissor") or \
             (user_choice == "paper" and computer_choice == "rock") or \
             (user_choice == "scissor" and computer_choice == "paper"):
            print("You win!\n")
        else:
            print("You lose!\n")

#call the function
rock_paper_scissor()